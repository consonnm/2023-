#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const double PI =3.14159269397;
struct work_table{
	int type,time_remain,mat_state,pro_state;
	double x,y;
	int flag[10];
};
struct robot{
	int ID,type;
	double time,collide,lineSpeed_x,lineSpeed_y;
	double angleSpeed,direction,x,y;
	int table_id;
	double new_ngleSpeed;
};
char mp[105][105]; 
void read_map(){
	for(int i=0;i<100;i++)
		for(int t=0;t<100;t++){
			cin>>mp[i][t];
		}
	string a;
	cin>>a;
}
double dis(robot robots,work_table work_tables){
	return sqrt((robots.x-work_tables.x)*(robots.x-work_tables.x)+(robots.y-work_tables.y)*(robots.y-work_tables.y));
}
double cal_angle(work_table work_tables,robot robots){
	double dy=work_tables.y-robots.y,dx=work_tables.x-robots.x;
    double rotation_angle = atan2(dy, dx) - robots.direction;
    if (rotation_angle > PI) {
        rotation_angle -= 2 * PI;
    } else if (rotation_angle < -PI) {
        rotation_angle += 2 * PI;
    }
    return rotation_angle;
}
double control(robot &robots,work_table *work_tables,int k,int *remain_mat){
	if(robots.type==0){
		int mi=0,flag=0;
		double sum=1e10;
		for(int i=0;i<k;i++){
			if(work_tables[i].type>3&&work_tables[i].pro_state>0){
				if(work_tables[i].flag[0]==0&&remain_mat[work_tables[i].type]>0){
					if(work_tables[i].type>work_tables[mi].type) mi=i,flag=1;
					else if(work_tables[i].type==work_tables[mi].type&&dis(robots,work_tables[i])<sum) mi=i,flag=1; 
					sum=dis(robots,work_tables[mi]);
				} 
			} 
			else if(work_tables[i].type==1||work_tables[i].type==2||work_tables[i].type==3){
				if(work_tables[i].flag[0]==0&&dis(robots,work_tables[i])<sum&&((((1<<robots.type)&&work_tables[i].mat_state))==0)&&remain_mat[work_tables[i].type]>0){
					if(flag==0||work_tables[mi].type<=3){
						mi=i,flag=1; 
						sum=dis(robots,work_tables[mi]);
					}
				} 
			}
		}
		if(flag==0) robots.new_ngleSpeed=0;
		work_tables[mi].flag[0]=1;
		remain_mat[work_tables[mi].type]--;
		robots.table_id=mi;
		robots.new_ngleSpeed=cal_angle(work_tables[mi],robots);
	}
	else if(robots.type==1){
		int mi=0,flag=0;
		double sum=1e10;
		for(int i=0;i<k;i++){
			if(work_tables[i].type==4||work_tables[i].type==5||work_tables[i].type==9){
				if(work_tables[i].flag[robots.type]==0&&dis(robots,work_tables[i])<sum&&((((1<<robots.type)&work_tables[i].mat_state))==0)){
					sum=dis(robots,work_tables[i]),mi=i;
					flag=1;
				} 
			}
			
		}
		if(flag==0) robots.new_ngleSpeed=0;
		work_tables[mi].flag[robots.type]=1;
		robots.table_id=mi;
		robots.new_ngleSpeed=cal_angle(work_tables[mi],robots);
	}
	else if(robots.type==2){
		int mi=0,flag=0;
		double sum=1e10;
		for(int i=0;i<k;i++){
			if(work_tables[i].type==4||work_tables[i].type==6||work_tables[i].type==9){
				if(work_tables[i].flag[robots.type]==0&&dis(robots,work_tables[i])<sum&&((((1<<robots.type)&work_tables[i].mat_state))==0)){
					sum=dis(robots,work_tables[i]),mi=i;
					flag=1;
				} 
			}
		}
		if(flag==0) robots.new_ngleSpeed=0;
		work_tables[mi].flag[robots.type]=1;
		robots.table_id=mi;
		robots.new_ngleSpeed=cal_angle(work_tables[mi],robots);
	}
	else if(robots.type==3){
		int mi=0,flag=0;
		double sum=1e10;
		for(int i=0;i<k;i++){
			if(work_tables[i].type==6||work_tables[i].type==5||work_tables[i].type==9){	
				if(work_tables[i].flag[robots.type]==0&&dis(robots,work_tables[i])<sum&&((((1<<robots.type)&work_tables[i].mat_state))==0)){
					sum=dis(robots,work_tables[i]),mi=i;
					flag=1;
				}
			}
		}
		if(flag==0) robots.new_ngleSpeed=0;
		work_tables[mi].flag[robots.type]=1;
		robots.table_id=mi;
		robots.new_ngleSpeed=cal_angle(work_tables[mi],robots);
	}
	else if(robots.type==4||robots.type==6||robots.type==5){
		int mi=0,flag=0;
		double sum=1e10;
		for(int i=0;i<k;i++){
			if(work_tables[i].type==7){
				if(work_tables[i].flag[robots.type]==0&&dis(robots,work_tables[i])<sum&&((((1<<robots.type)&work_tables[i].mat_state))==0)){
					sum=dis(robots,work_tables[i]),mi=i;
					flag=1;
				} 
			}
		}
		if(flag==0) robots.new_ngleSpeed=0;
		work_tables[mi].flag[robots.type]=1;
		robots.table_id=mi;
		robots.new_ngleSpeed=cal_angle(work_tables[mi],robots);
	}
	else if(robots.type==7){
		int mi=0,flag=0;
		double sum=1e10;
		for(int i=0;i<k;i++){
			if(work_tables[i].type==8){
				if(work_tables[i].flag[robots.type]==0&&dis(robots,work_tables[i])<sum&&((((1<<robots.type)&work_tables[i].mat_state))==0)){
					sum=dis(robots,work_tables[i]),mi=i;
					flag=1;
				} 
			}
		}
		if(flag==0) robots.new_ngleSpeed=0;
		work_tables[mi].flag[robots.type]=1;
		robots.table_id=mi;
		robots.new_ngleSpeed=cal_angle(work_tables[mi],robots);
	}
	return 0;
}
void check_remain_mat(work_table *work_tables,int *remain_mat,int k,robot *robots){
	for(int i=0;i<k;i++){
		if(work_tables[i].type==4){
			if(((1<<1)&work_tables[i].mat_state)==0) remain_mat[1]++;
			if(((1<<2)&work_tables[i].mat_state)==0) remain_mat[2]++;
		}
		if(work_tables[i].type==5){
			if(((1<<1)&work_tables[i].mat_state)==0) remain_mat[1]++;
			if(((1<<3)&work_tables[i].mat_state)==0) remain_mat[3]++;
		}
		if(work_tables[i].type==6){
			if(((1<<2)&work_tables[i].mat_state)==0) remain_mat[2]++;
			if(((1<<3)&work_tables[i].mat_state)==0) remain_mat[3]++;
		}
		if(work_tables[i].type==7){
			for(int t=4;t<=6;t++){
				if(((1<<t)&work_tables[i].mat_state)==0) remain_mat[t]++;
			}
		}
		if(work_tables[i].type==8){
			if(((1<<7)&work_tables[i].mat_state)==0) remain_mat[7]++;
		}
		if(work_tables[i].type==9){
			for(int t=1;t<=7;t++){
				if(((1<<t)&work_tables[i].mat_state)==0) remain_mat[t]++;
			}
		}
	}
	for(int i=0;i<4;i++){
		remain_mat[robots[i].type]--;
	}
}
int main() {
    read_map();
	puts("OK");
    fflush(stdout);
    int frameID;
    while (scanf("%d", &frameID) != EOF) {
    	printf("%d\n", frameID);
        int money=0,k;
        cin>>money>>k;
        work_table work_tables[k+1];
        robot robots[5];
        int remain_mat[10];
        for(int i=0;i<10;i++) remain_mat[i]=0;
        for(int i=0;i<k;i++){
        	cin>>work_tables[i].type>>work_tables[i].x>>work_tables[i].y;
			cin>>work_tables[i].time_remain;
			cin>>work_tables[i].mat_state>>work_tables[i].pro_state;
			for(int t=0;t<10;t++) work_tables[i].flag[t]=0;
		}
		for(int i=0;i<=3;i++){
			cin>>robots[i].ID>>robots[i].type>>robots[i].time>>robots[i].collide;
			cin>>robots[i].angleSpeed>>robots[i].lineSpeed_x>>robots[i].lineSpeed_y>>robots[i].direction>>robots[i].x>>robots[i].y;
		}
		string a;
		cin>>a;
		check_remain_mat(work_tables,remain_mat,k,robots);
		for(int i=0;i<4;i++){
			control(robots[i],work_tables,k,remain_mat);
		}
		for(int i=0;i<4;i++){
			for(int t=i+1;t<4;t++)
				if(robots[i].new_ngleSpeed*robots[t].new_ngleSpeed<0&&(fabs(robots[i].new_ngleSpeed-robots[t].new_ngleSpeed)-PI)<0.001){
					robots[i].new_ngleSpeed+=0.05;
					robots[i].new_ngleSpeed+=0.05;
				}
		}
        for(int i = 0; i< 4; i++){
        	double forward =0.5;
        	double angleSpeed=robots[i].new_ngleSpeed;
        	if(angleSpeed==0) forward=0;
        	else if(abs(angleSpeed)<=0.5) forward=6,angleSpeed=0;
        	if(angleSpeed>0) angleSpeed=PI;
			else if(angleSpeed<0)  angleSpeed=-PI;
            printf("forward %d %lf\n", i, forward);
            printf("rotate %d %lf\n", i, angleSpeed);
            if(robots[i].ID!=-1&&robots[i].table_id==robots[i].ID){
            	if(robots[i].type==0&&frameID<=8600){
            		printf("buy %d\n", i);
				} 
            	else printf("sell %d\n", i);
			}
        }
        printf("OK\n");
        fflush(stdout);
    }
    return 0;
}
